contentores(' R do Alecrim ',[355,356,357,358,359,364,365,366,367,368,369,370,360,361,362,363,371,372,373,374,375,376]).
contentores(' Lg Corpo Santo ',[333,334,335,336,337,338,339,342,343,344,340,341]).
contentores(' R Corpo Santo ',[377,378,379,380]).
contentores(' Tv Corpo Santo ',[381,382,383,384,385]).
contentores(' R Bernardino da Costa ',[386,387,388,389,390,391,392,393,394,395,396]).
contentores(' R da Boavista ',[418,419,420,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439]).
contentores(' Bqr do Duro ',[447,448,449,450,451]).
contentores(' Tv Marquês de Sampaio ',[417]).
contentores(' R São Paulo ',[504,505,506,507,508,509,510,511,512,513,514,515,516,517,518,519,520,521,522,523,524,525,526,527,528,529,530,531,532,533,534,535,536,537,538,539,540,541,542,543,544,545,546,547,548,549,550,551,552,553,554,555,556,563,564,557,558,559,560,561,562]).
contentores(' R Instituto Industrial ',[457,458,459,460]).
contentores(' R Cais do Tojo ',[441,442,443,444,445,446]).
contentores(' Tv do Cais do Tojo ',[440]).
contentores(' Av 24 de Julho ',[351,352,353,354]).
contentores(' R Dom Luís I ',[476,477,478,479,480,481,482,483,484]).
contentores(' R Moeda ',[463,464,465,466]).
contentores(' R Ribeira Nova ',[494,495,496,492,493,497,498,499,500,501,502,503]).
contentores(' Tv Carvalho ',[467,468,469,470,471,472,473,474,475]).
contentores(' R Remolares ',[584,585,586,587,588,589,590,591,592,593,594]).
contentores(' Pc São Paulo ',[642,643,644,645,646,647,648]).
contentores(' Tv dos Remolares ',[602,603,611,612,613,614,615,616,617,618,619,620,621,622]).
contentores(' Bc da Moeda ',[632,633]).
contentores(' R Nova do Carvalho ',[565,566,567,568,569,570,571,572,573,574,575,576,577,578,579,580,581,582,583]).
contentores(' Pc Duque da Terceira ',[649,650,651,652,653,654,655,656,657,658,659,660,661,662,663,664]).
contentores(' Cais do Sodré ',[623,624,625,626,627,628,629,630,631]).
contentores(' Tv Ribeira Nova ',[637,638]).
