adjacente(' R do Alecrim ',' R Nova do Carvalho ',314.45905740733394).
adjacente(' R do Alecrim ',' Pc Duque da Terceira ',774.3464641253521).
adjacente(' Lg Corpo Santo ',' R Corpo Santo ',485.014020072145).
adjacente(' Lg Corpo Santo ',' R Bernardino da Costa ',1136.3470501382728).
adjacente(' R Corpo Santo ',' Tv Corpo Santo ',635.2131988256051).
adjacente(' R Corpo Santo ',' R São Paulo ',4553.173324255925).
adjacente(' Tv Corpo Santo ',' R Bernardino da Costa ',455.9978375993996).
adjacente(' Tv Corpo Santo ',' Cais do Sodré ',414.22190130141405).
adjacente(' R Bernardino da Costa ',' Tv Corpo Santo ',455.9978375993996).
adjacente(' R Bernardino da Costa ',' Pc Duque da Terceira ',760.829441000835).
adjacente(' R da Boavista ',' Lg Conde-Barão ',1261.7872871049206).
adjacente(' R da Boavista ',' Tv Marquês de Sampaio ',1695.9145577704883).
adjacente(' R da Boavista ',' Pto Galega ',1232.8116294290387).
adjacente(' R da Boavista ',' Bc da Boavista ',231.9963202500747).
adjacente(' R da Boavista ',' Bc Francisco André ',937.8260127531659).
adjacente(' Bqr do Duro ',' Lg Conde-Barão ',926.6262843996432).
adjacente(' Bqr do Duro ',' R Dom Luís I ',3122.0984094990754).
adjacente(' Tv Marquês de Sampaio ',' R da Boavista ',1695.9145577704883).
adjacente(' R São Paulo ',' R da Boavista ',3859.0525019320767).
adjacente(' R São Paulo ',' R Moeda ',459.1814168732744).
adjacente(' R São Paulo ',' Tv dos Remolares ',3102.277736595507).
adjacente(' R São Paulo ',' Bc da Moeda ',765.4021142815892).
adjacente(' R São Paulo ',' Pc São Paulo ',2619.8409788958957).
adjacente(' R Instituto Industrial ',' R da Boavista ',1053.5203016446608).
adjacente(' R Instituto Industrial ',' R Dom Luís I ',2283.636013781568).
adjacente(' R Cais do Tojo ',' Tv do Cais do Tojo ',283.3377313128886).
adjacente(' R Cais do Tojo ',' Bqr do Duro ',492.32901815108846).
adjacente(' Tv do Cais do Tojo ',' R Cais do Tojo ',283.3377313128886).
adjacente(' Av 24 de Julho ',' R Instituto Industrial ',5991.298060713047).
adjacente(' Av 24 de Julho ',' Tv dos Remolares ',1281.982291623449).
adjacente(' Av 24 de Julho ',' Cais do Sodré ',2507.660009066652).
adjacente(' Av 24 de Julho ',' Pc Ribeira Nova ',487.0796361166529).
adjacente(' R Dom Luís I ',' R Instituto Industrial ',2283.636013781568).
adjacente(' R Dom Luís I ',' Pc Dom Luís I ',1574.8176632086625).
adjacente(' R Moeda ',' R São Paulo ',459.1814168732744).
adjacente(' R Ribeira Nova ',' Tv Carvalho ',617.2899665387008).
adjacente(' R Ribeira Nova ',' Pc Dom Luís I ',862.2366970510143).
adjacente(' Tv Carvalho ',' Tv Carvalho ',0).
adjacente(' Tv Carvalho ',' R São Paulo ',1017.4049409854302).
adjacente(' Tv Carvalho ',' Pc São Paulo ',1602.6961039737544).
adjacente(' R Remolares ',' R Ribeira Nova ',1454.3261086811574).
adjacente(' R Remolares ',' Tv Ribeira Nova ',296.0684768614923).
adjacente(' R Remolares ',' Pc Duque da Terceira ',880.644880139303).
adjacente(' Pc São Paulo ',' R São Paulo ',2619.8409788958957).
adjacente(' Pc São Paulo ',' R Nova do Carvalho ',1361.6131596038465).
adjacente(' Pc São Paulo ',' Tv de São Paulo ',874.5502183245542).
adjacente(' Tv dos Remolares ',' R São Paulo ',3102.277736595507).
adjacente(' Tv dos Remolares ',' R Nova do Carvalho ',879.8573561797047).
adjacente(' Tv dos Remolares ',' R Remolares ',619.9576308825473).
adjacente(' Tv dos Remolares ',' Av 24 de Julho ',1281.982291623449).
adjacente(' Bc da Moeda ',' R São Paulo ',765.4021142815892).
adjacente(' R Nova do Carvalho ',' Tv dos Remolares ',879.8573561797047).
adjacente(' Pc Duque da Terceira ',' R Remolares ',880.644880139303).
adjacente(' Pc Duque da Terceira ',' Cais do Sodré ',1529.2274887121991).
adjacente(' Pc Duque da Terceira ',' Av 24 de Julho ',985.6461209006703).
adjacente(' Cais do Sodré ',' Pc Duque da Terceira ',1529.2274887121991).
adjacente(' Cais do Sodré ',' Lg Corpo Santo ',896.4359918294742).
adjacente(' Tv Ribeira Nova ',' Pc São Paulo ',323.95449351866324).

rua(' R do Alecrim ',-9.14348180670535,38.7073026157039).
rua(' R Corpo Santo ',-9.14255098678099,38.7073286838222).
rua(' Tv Corpo Santo ',-9.1426225690344,38.7066975168166).
rua(' R Bernardino da Costa ',-9.14305015543156,38.7068559589223).
rua(' Lg Conde-Barão ',-9.15201897924565,38.708606605818).
rua(' Tv Marquês de Sampaio ',-9.14910552718357,38.709073383915).
rua(' R da Boavista ',-9.15079311664937,38.7089055507175).
rua(' Tv do Cais do Tojo ',-9.15206034846112,38.7082819634324).
rua(' R Cais do Tojo ',-9.15178357572543,38.7082213241484).
rua(' Bqr do Duro ',-9.1513885281045,38.7079275125773).
rua(' R Instituto Industrial ',-9.1505486401448,38.7078807891527).
rua(' R Moeda ',-9.14704425203433,38.7080193757895).
rua(' Tv Carvalho ',-9.14598863635406,38.7081636570213).
rua(' R Dom Luís I ',-9.14829055489657,38.7075401361692).
rua(' Pc Dom Luís I ',-9.14671590072996,38.7075628281927).
rua(' R Ribeira Nova ',-9.14585366538093,38.7075613035211).
rua(' R São Paulo ',-9.14695866414731,38.7084705102342).
rua(' R Nova do Carvalho ',-9.14319266057494,38.7071790073949).
rua(' R Remolares ',-9.14447892499263,38.7070868003123).
rua(' Tv dos Remolares ',-9.14401335962188,38.7074961856438).
rua(' Cais do Sodré ',-9.14222984894838,38.7065657946941).
rua(' Bc da Moeda ',-9.14622006213417,38.7082697430488).
rua(' Pto Galega ',-9.14956443154647,38.7090063348014).
rua(' Bc da Boavista ',-9.15059949287472,38.709033347926).
rua(' Tv Ribeira Nova ',-9.1446205470921,38.7073467997814).
rua(' Pc Ribeira Nova ',-9.14476400355141,38.7069221884751).
rua(' Pc São Paulo ',-9.14447518350945,38.7076363096132).
rua(' Pc Duque da Terceira ',-9.1437590142256,38.7065795884311).
rua(' Lg Corpo Santo ',-9.1420813502454,38.7074498453842).
rua(' Bc Francisco André ',-9.14986368552042,38.7090307521821).
rua(' Tv de São Paulo ',-9.14534815013291,38.7075837039225).
rua(' Av 24 de Julho ',-9.14473414894124,38.7064360246404).
